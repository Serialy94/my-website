document.querySelector('button').addEventListener('click', function() {
    alert('Netflix-style theme activated!');
});
